<?php
require_once( "BatchAntiSpoofClass.php" );

$maintClass = "BatchAntiSpoof";
require_once( DO_MAINTENANCE );
